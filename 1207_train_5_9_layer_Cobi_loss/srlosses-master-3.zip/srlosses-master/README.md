# SRLosses

## Intorduction
This repo aims to provide a collections of loss functions used for deep learning based super-resolution.
## Usage
### Perceptual Loss
```python
from srlosses import Perceptual_Loss
```
### CoBi Loss
```python
from srlosses import CoBi_Loss, Patch_CoBi_Loss
```
**Note**: setting w_spatial=0, the CoBi Loss become the standard contextual loss.
### MSGMS Loss
```python
from srlosses import MSGMS_Loss
```

## Issues
### Input Normalization of cnn-based Loss
torchvision documents (https://pytorch.org/docs/stable/torchvision/models.html) state that the input to the VGG19 network should be normalized using mean = [0.485, 0.456, 0.406] and std = [0.229, 0.224, 0.225]. But some open source implementations puts an image that is simply normalized in the scale of -1 ~ 1, including (https://github.com/NVIDIA/pix2pixHD). In this implementation, I used normalized according to torchvision, however, this could be further stuied in the future.

## TODO
- [ ] CPU and CUDA version
- [ ] SSIM and MSSIM Loss
- [ ] L1 and L2 Loss

## Contact
Please contact me if there is any question (Chao Zhang <chao46.zhang@tcl.com>).