import torch
import os
os.environ["CUDA_VISIBLE_DEVICES"] = str(3)
import torch.nn as nn
from srlosses import CoBi_Loss

a = torch.rand((8,1,224,224))
b = torch.rand((8,1,224,224))

print(CoBi_Loss()(a,b))